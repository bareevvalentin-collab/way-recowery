# Путь — быстрый деплой (Render / Railway / Replit)

## Быстрый запуск локально
```
npm install
npm start
# Открой http://localhost:3000/put_site_full.html
```

## Render.com (Web Service)
1) Залей папку в репозиторий GitHub (или импортируй этот архив).
2) На Render: New → Web Service → подключи репозиторий.
3) Build Command: `npm install`
4) Start Command: `npm start`
5) После билда Render выдаст публичный URL вида `https://<name>.onrender.com/`
   Открой `<url>/put_site_full.html` с телефона.

## Railway.app (Node.js Service)
1) Создай новый проект → Deploy from GitHub.
2) CMD: `npm start` (Railway сам поставит зависимости).
3) Открой публичный домен проекта → `/put_site_full.html`.

## Replit (самый быстрый без Git)
1) Создай Repl → "Node.js".
2) Залей файлы (перетащи из архива).
3) В "Shell":
```
npm install
node put_server_static.js
```
4) Нажми "Open in new tab" — получишь публичный URL. Перейди на `/put_site_full.html`.

## Примечания
- Данные сохраняются на сервере в `put_db.json` (в корне проекта).
- Фронт обращается к API по пути `/api/*` (один домен).

